<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>exercicio 2</title>
</head>
<body>
    <h1>exercicio 2</h1>
    <form action="exercicio2.php" method="post">
        Numero 1:<input type="text" name="numero1" /><br />
        Numero 2:<input type="text" name="numero2" /><br />
        Numero 3:<input type="text" name="numero3" /><br />
        <input type="submit" name="submit" value="Testar" />
    </form> 
</body>
</html>